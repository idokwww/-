package com.example.ace6iphonespoof;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;

public final class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        TextView text = new TextView(this);
        text.setTextSize(15);
        text.setPadding(36, 36, 36, 36);
        text.setText(
                "Ace6 iPhone Spoof\n\n"
                        + "目标伪装机型：iPhone 17 Pro\n\n"
                        + "使用方式：\n"
                        + "1. 在 LSPosed 中启用本模块。\n"
                        + "2. 在作用域中选择需要伪装的应用，或按需选择系统框架/目标应用。\n"
                        + "3. 强制停止目标应用后重新打开。\n"
                        + "4. 关闭 LSPosed 模块或移除作用域后，新启动的应用会恢复读取原始信息。\n\n"
                        + "本模块只 Hook 上层 Java API：Build、Build.VERSION、SystemProperties 和部分 getprop 进程调用。\n\n"
                        + "限制说明：\n"
                        + "无法修改内核标识、CPU 架构、硬件节点、/proc 文件、/sys 文件、TEE、KeyStore、SafetyNet、Play Integrity、厂商安全校验或原生 native 直接读取。\n\n"
                        + "免责声明：\n"
                        + "代码仅限安卓逆向技术学习研究，严禁用于绕过风控、游戏作弊、违规用途。请遵守法律法规。"
        );

        ScrollView scroll = new ScrollView(this);
        scroll.addView(text);
        setContentView(scroll);
    }
}
