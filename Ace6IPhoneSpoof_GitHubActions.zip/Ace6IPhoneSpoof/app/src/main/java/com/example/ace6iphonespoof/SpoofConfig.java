package com.example.ace6iphonespoof;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

final class SpoofConfig {
    static final String BRAND = "Apple";
    static final String MANUFACTURER = "Apple";
    static final String MODEL = "iPhone 17 Pro";
    static final String PRODUCT = "iPhone17Pro";
    static final String DEVICE = "iPhone17,1";
    static final String BOARD = "t8140";
    static final String HARDWARE = "A19Pro";
    static final String FINGERPRINT =
            "Apple/iPhone17Pro/iPhone17,1:18.0/22A3354/22A3354:user/release-keys";

    static final Map<String, String> PROPS;

    static {
        Map<String, String> props = new HashMap<>();

        props.put("ro.product.brand", BRAND);
        props.put("ro.product.manufacturer", MANUFACTURER);
        props.put("ro.product.model", MODEL);
        props.put("ro.product.name", PRODUCT);
        props.put("ro.product.device", DEVICE);
        props.put("ro.product.board", BOARD);

        props.put("ro.product.system.brand", BRAND);
        props.put("ro.product.system.manufacturer", MANUFACTURER);
        props.put("ro.product.system.model", MODEL);
        props.put("ro.product.system.name", PRODUCT);
        props.put("ro.product.system.device", DEVICE);

        props.put("ro.product.vendor.brand", BRAND);
        props.put("ro.product.vendor.manufacturer", MANUFACTURER);
        props.put("ro.product.vendor.model", MODEL);
        props.put("ro.product.vendor.name", PRODUCT);
        props.put("ro.product.vendor.device", DEVICE);

        props.put("ro.build.fingerprint", FINGERPRINT);
        props.put("ro.system.build.fingerprint", FINGERPRINT);
        props.put("ro.vendor.build.fingerprint", FINGERPRINT);
        props.put("ro.bootimage.build.fingerprint", FINGERPRINT);

        props.put("ro.hardware", HARDWARE);
        props.put("ro.board.platform", BOARD);
        props.put("ro.build.product", DEVICE);
        props.put("ro.build.description", "iPhone17Pro-user 18.0 22A3354 release-keys");

        props.put("ro.build.version.release", "18.0");
        props.put("ro.build.version.incremental", "22A3354");
        props.put("ro.build.version.security_patch", "2025-09-01");
        props.put("ro.build.tags", "release-keys");
        props.put("ro.build.type", "user");
        props.put("ro.build.user", "apple");
        props.put("ro.build.host", "build.apple.com");

        PROPS = Collections.unmodifiableMap(props);
    }

    private SpoofConfig() {
    }

    static String prop(String key) {
        return PROPS.get(key);
    }
}
