package com.example.ace6iphonespoof;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;

final class SpoofProcess extends Process {
    private static final OutputStream NULL_OUTPUT = new OutputStream() {
        @Override
        public void write(int b) {
        }
    };

    private final ByteArrayInputStream stdout;
    private final ByteArrayInputStream stderr = new ByteArrayInputStream(new byte[0]);

    SpoofProcess(String output) {
        this.stdout = new ByteArrayInputStream(output.getBytes());
    }

    @Override
    public OutputStream getOutputStream() {
        return NULL_OUTPUT;
    }

    @Override
    public InputStream getInputStream() {
        return stdout;
    }

    @Override
    public InputStream getErrorStream() {
        return stderr;
    }

    @Override
    public int waitFor() {
        return 0;
    }

    @Override
    public int exitValue() {
        return 0;
    }

    @Override
    public void destroy() {
    }
}
