package com.example.ace6iphonespoof;

import android.os.Build;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.IXposedHookZygoteInit;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public final class XposedEntry implements IXposedHookZygoteInit, IXposedHookLoadPackage {
    private static final String SELF = "com.example.ace6iphonespoof";
    private static volatile boolean processHooksInstalled;

    @Override
    public void initZygote(StartupParam startupParam) {
        spoofBuildFields();
        hookSystemProperties(null);
        hookProcessApis();
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (SELF.equals(lpparam.packageName)) {
            return;
        }

        spoofBuildFields();
        hookSystemProperties(lpparam.classLoader);
        hookBuildGetSerial();
        hookProcessApis();
    }

    private static void spoofBuildFields() {
        setStaticField(Build.class, "BRAND", SpoofConfig.BRAND);
        setStaticField(Build.class, "MANUFACTURER", SpoofConfig.MANUFACTURER);
        setStaticField(Build.class, "MODEL", SpoofConfig.MODEL);
        setStaticField(Build.class, "PRODUCT", SpoofConfig.PRODUCT);
        setStaticField(Build.class, "DEVICE", SpoofConfig.DEVICE);
        setStaticField(Build.class, "BOARD", SpoofConfig.BOARD);
        setStaticField(Build.class, "HARDWARE", SpoofConfig.HARDWARE);
        setStaticField(Build.class, "FINGERPRINT", SpoofConfig.FINGERPRINT);
        setStaticField(Build.class, "ID", "22A3354");
        setStaticField(Build.class, "DISPLAY", "22A3354");
        setStaticField(Build.class, "TAGS", "release-keys");
        setStaticField(Build.class, "TYPE", "user");
        setStaticField(Build.class, "USER", "apple");
        setStaticField(Build.class, "HOST", "build.apple.com");

        setStaticField(Build.VERSION.class, "RELEASE", "18.0");
        setStaticField(Build.VERSION.class, "INCREMENTAL", "22A3354");
        setStaticField(Build.VERSION.class, "SECURITY_PATCH", "2025-09-01");
        setStaticField(Build.VERSION.class, "BASE_OS", "");
    }

    private static void hookSystemProperties(ClassLoader loader) {
        try {
            Class<?> cls = XposedHelpers.findClass("android.os.SystemProperties", loader);

            XposedHelpers.findAndHookMethod(cls, "get", String.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    String spoof = SpoofConfig.prop((String) param.args[0]);
                    if (spoof != null) {
                        param.setResult(spoof);
                    }
                }
            });

            XposedHelpers.findAndHookMethod(cls, "get", String.class, String.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    String spoof = SpoofConfig.prop((String) param.args[0]);
                    if (spoof != null) {
                        param.setResult(spoof);
                    }
                }
            });

            XposedHelpers.findAndHookMethod(cls, "getInt", String.class, int.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    String spoof = SpoofConfig.prop((String) param.args[0]);
                    if (spoof != null) {
                        try {
                            param.setResult(Integer.parseInt(spoof));
                        } catch (NumberFormatException ignored) {
                        }
                    }
                }
            });

            XposedHelpers.findAndHookMethod(cls, "getLong", String.class, long.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    String spoof = SpoofConfig.prop((String) param.args[0]);
                    if (spoof != null) {
                        try {
                            param.setResult(Long.parseLong(spoof));
                        } catch (NumberFormatException ignored) {
                        }
                    }
                }
            });

            XposedHelpers.findAndHookMethod(cls, "getBoolean", String.class, boolean.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    String spoof = SpoofConfig.prop((String) param.args[0]);
                    if (spoof != null) {
                        param.setResult(Boolean.parseBoolean(spoof));
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("Ace6IPhoneSpoof SystemProperties hook failed: " + t);
        }
    }

    private static void hookBuildGetSerial() {
        try {
            XposedHelpers.findAndHookMethod(Build.class, "getSerial", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    param.setResult("C02IPHONE17PRO");
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private static void hookProcessApis() {
        if (processHooksInstalled) {
            return;
        }
        processHooksInstalled = true;

        try {
            XposedHelpers.findAndHookMethod(ProcessBuilder.class, "start", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    ProcessBuilder builder = (ProcessBuilder) param.thisObject;
                    Process process = fakeGetprop(builder.command());
                    if (process != null) {
                        param.setResult(process);
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("Ace6IPhoneSpoof ProcessBuilder hook failed: " + t);
        }

        try {
            XposedHelpers.findAndHookMethod(Runtime.class, "exec", String.class, new RuntimeExecHook());
            XposedHelpers.findAndHookMethod(Runtime.class, "exec", String.class, String[].class, new RuntimeExecHook());
            XposedHelpers.findAndHookMethod(Runtime.class, "exec", String.class, String[].class, java.io.File.class, new RuntimeExecHook());
            XposedHelpers.findAndHookMethod(Runtime.class, "exec", String[].class, new RuntimeExecHook());
            XposedHelpers.findAndHookMethod(Runtime.class, "exec", String[].class, String[].class, new RuntimeExecHook());
            XposedHelpers.findAndHookMethod(Runtime.class, "exec", String[].class, String[].class, java.io.File.class, new RuntimeExecHook());
        } catch (Throwable t) {
            XposedBridge.log("Ace6IPhoneSpoof Runtime.exec hook failed: " + t);
        }
    }

    private static final class RuntimeExecHook extends XC_MethodHook {
        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            Object command = param.args[0];
            Process process;
            if (command instanceof String) {
                process = fakeGetprop((String) command);
            } else if (command instanceof String[]) {
                process = fakeGetprop((String[]) command);
            } else {
                process = null;
            }

            if (process != null) {
                param.setResult(process);
            }
        }
    }

    private static Process fakeGetprop(String command) {
        if (command == null) {
            return null;
        }
        String trimmed = command.trim();
        if (!trimmed.startsWith("getprop") && !trimmed.startsWith("/system/bin/getprop")) {
            return null;
        }
        return fakeGetprop(trimmed.split("\\s+"));
    }

    private static Process fakeGetprop(String[] command) {
        if (command == null || command.length == 0) {
            return null;
        }

        String first = command[0];
        if (!"getprop".equals(first) && !first.endsWith("/getprop")) {
            return null;
        }

        if (command.length >= 2) {
            String spoof = SpoofConfig.prop(command[1]);
            if (spoof != null) {
                return new SpoofProcess(spoof + "\n");
            }
            return null;
        }

        return new SpoofProcess(formatAllProps());
    }

    private static Process fakeGetprop(List<String> command) {
        if (command == null || command.isEmpty()) {
            return null;
        }

        String first = command.get(0);
        if (!"getprop".equals(first) && !first.endsWith("/getprop")) {
            return null;
        }

        if (command.size() >= 2) {
            String spoof = SpoofConfig.prop(command.get(1));
            if (spoof != null) {
                return new SpoofProcess(spoof + "\n");
            }
            return null;
        }

        return new SpoofProcess(formatAllProps());
    }

    private static String formatAllProps() {
        StringBuilder all = new StringBuilder();
        for (Map.Entry<String, String> entry : SpoofConfig.PROPS.entrySet()) {
            all.append("[")
                    .append(entry.getKey())
                    .append("]: [")
                    .append(entry.getValue())
                    .append("]\n");
        }
        return all.toString();
    }

    private static void setStaticField(Class<?> cls, String name, Object value) {
        try {
            Field field = cls.getDeclaredField(name);
            field.setAccessible(true);
            field.set(null, value);
        } catch (Throwable t) {
            XposedBridge.log("Ace6IPhoneSpoof set field failed: "
                    + cls.getName() + "." + name + " " + t);
        }
    }
}
